// CSCI Fall 2020
// Author: Jocelyn McHugo
// Recitation: 318 - Maria Stull
// [assignment] -- Problem #[]

#ifndef SECUNDUMPRINCIPUM_SKILL_H
#define SECUNDUMPRINCIPUM_SKILL_H

#include <string>
using namespace std;

class Skill {
public:
    Skill();
    Skill(string skillName_); // auto-generate skill level
    Skill(string skillName_, int skillLevel_);
private:
    string skillName;
    int skillLevel;
};


#endif //SECUNDUMPRINCIPUM_SKILL_H
