// CSCI Fall 2020
// Author: Jocelyn McHugo
// Recitation: 318 - Maria Stull
// [assignment] -- Problem #[]

#ifndef SECUNDUMPRINCIPUM_USER_H
#define SECUNDUMPRINCIPUM_USER_H


#include "TeamMember.h"
#include "Gear.h"
#include <string>

using namespace std;

class User : public TeamMember {
public:
    User();
    User(string firstName_, string lastName_, Skill skills[], int teamConf_, int health_, int teamSlotsFilled_,
         Gear inventory_, TeamMember team_[], int progress_);
    User(string firstName, string lastName_);

    int addTeamMember(TeamMember member_);
    TeamMember getTeamMember(string first_, string last_);
    void setGear(Gear newGear_);
    Gear getGear();
    //TODO make sure doing user.getGear().fillSlot("item") works the way it should
    
private:
    int teamConf;
    int health;
    static const int TEAM_SLOTS = 6;
    int teamSlotsFilled;
    Gear inventory;
    TeamMember team[TEAM_SLOTS];
    int progress; // out of 10
};


#endif //SECUNDUMPRINCIPUM_USER_H
